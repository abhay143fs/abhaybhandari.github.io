# Abhay Bhandari — Portfolio
A dark-themed, multi-page personal portfolio built with HTML, CSS, and JavaScript.

## How to publish on GitHub Pages
1. Create a new repository named `abhaybhandari.github.io`.
2. Upload all files (index.html, about.html, projects.html, contact.html, css/, js/).
3. Commit changes — GitHub Pages automatically publishes.
4. Visit [https://abhaybhandari.github.io](https://abhaybhandari.github.io)
